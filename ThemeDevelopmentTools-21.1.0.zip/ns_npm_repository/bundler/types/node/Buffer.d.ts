declare class Buffer {
    public static from(str: string): Buffer;
}




