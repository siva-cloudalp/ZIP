define('Dependency3', [], function() {});
