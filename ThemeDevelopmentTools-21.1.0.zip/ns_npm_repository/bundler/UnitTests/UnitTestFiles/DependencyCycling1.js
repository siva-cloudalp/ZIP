define('DependencyCycling1', ['EntryPointCycling1'], function() {});
