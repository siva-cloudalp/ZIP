define('Utils', ['SC.Models.Init'], function(ModelsInit) {});
