var _ = require('underscore')
,	tool = require('../tool');

tool.easy={};
require('./filecabinet');