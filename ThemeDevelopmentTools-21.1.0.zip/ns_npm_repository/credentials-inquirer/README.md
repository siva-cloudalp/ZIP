a simple command line interactive tool for asking for a netsuite user credentials, this is email, password, role and account. 

Based on inquirer.

See test.js