module.exports = {
    mock() {
        return { join: jest.fn() };
    }
};
